export interface ICategory {
    name : string;
    _id? : string;
    createdAt?: Date;
    updatedAt?: Date;
}